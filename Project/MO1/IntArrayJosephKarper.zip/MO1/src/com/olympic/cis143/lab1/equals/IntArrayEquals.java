package com.olympic.cis143.lab1.equals;

public class IntArrayEquals {

	public IntArrayEquals(int[] is) {
	  return;
	}

}
