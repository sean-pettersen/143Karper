
public class ArrayTest
{

	public static void main(String[] args)
	{
		ArrayIntList list1 = new ArrayIntList(11);
		list1.add(3);
		list1.add(4);
		list1.add(5);
		//list1.remove(0);
		//list1.add(5);
		
		ArrayIntList list2 = new ArrayIntList(10);
		list2.add(3);
		list2.add(4);
		list2.add(5);
		//list2.add(3);
		//list2.add(6);
		
		//list1.reflect();
		//list2.reflect();
		System.out.println(list1);
		System.out.println(list2);
		//System.out.println(list1.get(1));
		System.out.println(list1.compareTo(list2));
		System.out.println(list1.equals(list2));
		
		
		
		//ArrayIntList list2 = new ArrayIntList(4);
	}

}
